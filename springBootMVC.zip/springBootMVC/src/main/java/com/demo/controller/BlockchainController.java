/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 *
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.Block;
import com.demo.model.Blockchain;
import com.demo.model.Transaction;
import com.demo.service.BlockService;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
@Controller
public class BlockchainController {
    
    @Autowired
    BlockService blockService;
    
    List<Block> blockchain;
    
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView createGenesisBlock() {
        
        

        System.out.println("in controller");
        
        //create genesis block
        blockService.createGenesisBlock();        
        
        blockchain = blockService.getBlockchain();
        return new ModelAndView("index", "blockchain",  blockchain);
    }
    
    @RequestMapping(value="/transact")
    public ModelAndView transact(){
        return new ModelAndView("transact", "", null);
    }
    
    @RequestMapping(value="/addTransaction")
    public ModelAndView startTransaction(@ModelAttribute("transaction") Transaction t){
        String msg = "";
        
        msg = blockService.addTransaction(t);
                    
        return new ModelAndView("transact", "msg", msg);
    }
    
    @RequestMapping(value = "/mineBlock", method = RequestMethod.GET)
    public ModelAndView mineBlock() {
        System.out.println("in show bc controller");
       
        String msg = "";
        
        int[] nonce = blockService.mineBlock();
        boolean validBlock = blockService.checkBlock(nonce);
      
        if(validBlock){
            //blockService.addblock();
            msg = "Block added successfully!!";

        }
        else{
            msg = "Invalid block!!";
        }
        
        return new ModelAndView("transact", "msg",  msg);
    }
    
    @RequestMapping(value = "/showBlockchain", method = RequestMethod.GET)
    public ModelAndView showBlockchain() {

        System.out.println("in show bc controller");         
        
        blockchain = blockService.getBlockchain();
        
        return new ModelAndView("index", "blockchain",  blockchain);
    }
}

package com.demo.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.Block;
import com.demo.model.Blockchain;
import com.demo.model.Transaction;

@Service
public class BlockService {
    
    @Autowired 
    Blockchain blockchain;    
    
    public void createGenesisBlock(){
        blockchain.createGenesisBlock();
    }
    
//    public void addblock() {
//        blockchain.addblock();       
//    }

//    public Block createBlock(Transaction t) {
//        return blockchain.createBlock(t);        
//    }

    public int[] mineBlock() {
        // TODO Auto-generated method stub
        return blockchain.mineBlock();
    }

    public boolean checkBlock(int[] check) {
        return blockchain.checkBlock(check);
    }

    public String addTransaction(Transaction t) {
        return blockchain.addTransaction(t);
    }

    public List<Block> getBlockchain() {
        
        return blockchain.getBlockchain();
    }
}

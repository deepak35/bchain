package com.demo.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.stereotype.Service;

import com.demo.model.Block;

@Service
public class HashService {

    public static byte[] getBlockHash(Block block){
        
        //create string from block contents
        String data = Integer.toString(block.getIndex()) + block.getPreviousHash() + block.getTransactions().toString() + block.getTimeStamp();
        
        return hash(data);
               
    }

    public static byte[] hash(String data) {
      //create block hash
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            
            return messageDigest.digest(data.getBytes());
            
        } catch (NoSuchAlgorithmException e) {
            System.out.println("hash calculation failed");
            e.printStackTrace();
            return null;
        }
    }
}

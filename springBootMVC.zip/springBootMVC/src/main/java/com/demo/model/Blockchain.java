package com.demo.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.service.BlockService;
import com.demo.service.HashService;

@Component
public class Blockchain {

    private int chainSize;
    private List<Transaction> currentTransactions;
    private Block currentBlock, newBlock;
    
    private List<Block> blockchain;
    BlockService bs;
    
    public Blockchain(){
        blockchain = new ArrayList<Block>();
        bs = new BlockService();
        currentTransactions = new ArrayList<Transaction>();
        System.out.println("in ()");

    }
    public void addblock(){
        //System.out.println("block added before:"+currentBlock.toString());
        blockchain.add(currentBlock);
        currentBlock = null;
        
        //System.out.println("block added after:"+currentBlock.toString());

        currentTransactions = new ArrayList<Transaction>();

        //System.out.println("in addblock cb size:"+currentBlock.getTransactions().size());

        chainSize++;
    }
    public List<Block> getBlockchain() {
        for(Block b : blockchain){
            System.out.println(b.toString());

        }
        return blockchain;
    }
    public void setBlockchain(List<Block> blockchain) {
        this.blockchain = blockchain;
    }
    
    public int getChainSize() {
        return chainSize;
    }
    
    public void createGenesisBlock() {
                
        Block genesisBlock = new Block();
        
        genesisBlock.setIndex(0);
        genesisBlock.setPreviousHash(Integer.toString(0));
        genesisBlock.setTransactions(new ArrayList<Transaction>());
        genesisBlock.setTimeStamp("0");
        genesisBlock.setBlockHash(HashService.getBlockHash(genesisBlock));

        currentBlock = genesisBlock;
        addblock();

    }
    public Block createBlock(List<Transaction> t) {

        newBlock = new Block();
        System.out.println("creating new block, current txn size:"+t.size());
        newBlock.setIndex(getLastBlock().getIndex() + 1);
        newBlock.setPreviousHash(getLastBlock().getBlockHash());
        newBlock.setTransactions(t);
        newBlock.setTimeStamp(getCurrentTimeStamp());
        newBlock.setBlockHash(HashService.getBlockHash(newBlock));
        

        currentBlock = newBlock;
        return newBlock;
    }
    private String getCurrentTimeStamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
    }
    
    public int[] mineBlock() {
        // TODO Auto-generated method stub
        //Block newBlock = currentBlock;
        System.out.println("mine block:"+currentBlock.toString());
        String data = currentBlock.getBlockHash();
        int tempNonce = 0;
        int[] check = new int[2];
        String newData = data + Integer.toString(tempNonce);
        
        byte[] dataHash = HashService.hash(newData);
        
        System.out.println("Mining");
        while(dataHash[0] != 0){
            System.out.println("...");
            tempNonce++;
            newData = data + Integer.toString(tempNonce);
            dataHash = HashService.hash(newData);
        }
        System.out.println("Mining done!");
        check[0] = tempNonce;
        check[1] = dataHash[0];
        
        currentBlock.setNonce(tempNonce);
        return check;
    }
    public boolean checkBlock(int[] check) {
        //Block newBlock = currentBlock;
        
        byte[] tempHash = HashService.hash(currentBlock.getBlockHash() + Integer.toString(check[0]));
        
        if(tempHash[0] == check[1]){
            addblock();
            return true;
        }
        return false;
    }
    public String addTransaction(Transaction t) {
        if(currentTransactions.size() <2){
            currentTransactions.add(t);
            
            if(currentTransactions.size() == 2){
                Block tempBlock = createBlock(currentTransactions);
                return "Block full, index: "+tempBlock.getIndex()+", \nmine it first to add more transactions";
            }
            return "transaction added to block number: " + (chainSize+1);
        }
        else{
            return "mine new block first to add more transactions";
        }
    }
    
    public Block getLastBlock(){
        System.out.println(blockchain.size());
        return blockchain.get(blockchain.size()-1);
    }
    
    
}

package com.demo.model;

import java.util.ArrayList;
import java.util.List;

public class Block {

    private int index;
    private String blockHash, previousHash;
    private List<Transaction> transactions;
    @Override
    public String toString() {
        return "Block [index=" + index + ", blockHash=" + blockHash + ", previousHash=" + previousHash + ", transactions="
            + transactions + ", timeStamp=" + timeStamp + ", nonce=" + nonce + "]";
    }

    private String timeStamp;
    private int nonce;
    
//    public Block(){
//        transactions = new ArrayList<Transaction>();
//    }
    
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }
    public String getBlockHash() {
        return blockHash;
    }
    public void setBlockHash(byte[] blockHash) {     
        this.blockHash = hashToString(blockHash);
    }
    public String getPreviousHash() {
        return previousHash;
    }
    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }
    public List<Transaction> getTransactions() {
        return transactions;
    }
    public void setTransactions(List<Transaction> t) {
        System.out.println("in block:"+t.toString());
        this.transactions = t;
    }
    public String getTimeStamp() {
        return timeStamp;
    }
    public int getNonce() {
        return nonce;
    }
    public void setNonce(int nonce) {
        this.nonce = nonce;
    }
    public void setBlockHash(String blockHash) {
        this.blockHash = blockHash;
    }
    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }
    
    public String hashToString(byte[] hash){
        
        String hashString = "";
        for(byte b : hash){
            hashString += Byte.toString(b);
        }
        
        return hashString;
    }
}

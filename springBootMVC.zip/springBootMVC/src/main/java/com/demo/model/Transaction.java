package com.demo.model;

public class Transaction {

    private String source;
    private String destination;
    private int amount;
    
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public String getDestination() {
        return destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    @Override
    public String toString() {
        return "Transaction [source=" + source + ", destination=" + destination + ", amount=" + amount + "]";
    }
}
